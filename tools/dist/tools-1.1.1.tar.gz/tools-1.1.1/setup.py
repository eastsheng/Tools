from distutils.core import setup

setup(

	name         = 'tools',
	version      = '1.1.1',
	py_modules   = ['tools'],
	author       = 'DongshengChen',
	author_email = 'eastsheng@hotmail.com',
	url          = 'https://github.com/eastsheng',
	description  = 'Some tools.'
	)
